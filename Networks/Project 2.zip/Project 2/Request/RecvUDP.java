import java.net.*;  // for DatagramSocket and DatagramPacket
import java.io.*;   // for IOException

public class RecvUDP {

   public static void main(String[] args) throws Exception {
      System.out.println("Waiting for senders");
      if (args.length != 1 && args.length != 2)  // Test for correct # of args        
      {
         throw new IllegalArgumentException("Parameter(s): <Port> [<encoding>]");
      }
      int port = Integer.parseInt(args[0]);   // Receiving Port
      
      DatagramSocket sock = new DatagramSocket(port);  // UDP socket for receiving      
      DatagramPacket packet = new DatagramPacket(new byte[1024],1024);
      System.out.println(packet.getLength());
      while(true){
         sock.receive(packet);
         System.out.println(packet.getLength());
         RequestDecoder decoder = (args.length == 2 ?   // Which encoding              
              new RequestDecoderBin(args[1]) :
              new RequestDecoderBin());
      
      
         Request receivedRequest = decoder.decode(packet);
         if(receivedRequest.tml == -1){
            break;
         }
         System.out.println("Received Binary-Encoded Request");
         int result = 0;
         switch (receivedRequest.operandCode) {
            case 0:
               result = receivedRequest.operand1 + receivedRequest.operand2;
               break;
            case 1:
               result = receivedRequest.operand1 - receivedRequest.operand2;
               break;
            case 2:
               result = receivedRequest.operand1 * receivedRequest.operand2;
               break;
            case 3:
               result = receivedRequest.operand1 / receivedRequest.operand2;
               break;
            case 4:
               result = receivedRequest.operand1 >> receivedRequest.operand2;
               break;
            case 5:
               result = receivedRequest.operand1 << receivedRequest.operand2;
               break;
            
            default:
               result = ~receivedRequest.operand1;
               break;
         }
      
         System.out.println(result);
         System.out.println(receivedRequest);
      }
      
      sock.close();
   }
}
