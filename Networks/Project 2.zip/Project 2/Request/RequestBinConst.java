public interface RequestBinConst {
    public static final String DEFAULT_ENCODING = "ISO-8859-1";
}
