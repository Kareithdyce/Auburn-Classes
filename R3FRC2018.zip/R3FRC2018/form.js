function myFunction(){
    var id  = { name: document.getElementById("name").value,
                company: document.getElementById("text1").value,
                years: document.getElementById("text2").value,
                city: document.getElementById("text3").value };
    
    console.log(id);
            }